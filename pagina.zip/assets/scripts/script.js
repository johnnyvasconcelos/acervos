const vm = new Vue({
    el: "#app",
    data: {
        btnMobile: false,
        submenu: false
    }
})